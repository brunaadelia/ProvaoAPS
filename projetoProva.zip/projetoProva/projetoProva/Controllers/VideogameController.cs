using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using projetoProva.Models;

namespace projetoProva.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class VideogameController : ControllerBase
    {
        private BDContexto contexto;
        
        public VideogameController(BDContexto bdContexto)
        {
            contexto = bdContexto;
        }
        
        [HttpGet]
        public List<Videogame> Listar(string order)
        {
             return contexto.Videogame.Include(c => c.IdVideogameNavigation).Select
             (
                 c => new Videogame 
                 { 
                     Id = c.Id,
                     Nome = c.Nome,
                      Fabricante = c.Fabricante,
                      Geraçao = c.Geraçao,
                      Ano = c.Ano
                      
                    }
                ).ToList();
        }

        [HttpGet]

        public List<Videogame> ListarPorFabricante(string fabricante)
        {
            return contexto.Videogame.Where(c => c.Fabricante).Select
            (
                c => new Videogame
                { 
                    Id = c.Id,
                    Nome = c.Nome,
                    Fabricante = c.Fabricante,
                    Geraçao = c.geraçao,
                    Ano = c.Ano,

                }).ToList();
        }
            
        }


        [HttpGet]
        public List<Videogame> Visualizar(int id)
        {
            
        }


        [HttpPost]
        public string Cadastrar([FromBody]Videogame dados)
        {
            contexto.Add(dados);
            contexto.SaveChanges();
            
            return "VideoGame cadastrado com sucesso!";
            
        }

        [HttpDelete]
        public string Excluir([FromBody]int id)
        {
            Videogame dados = contexto.Videogame.FirstOrDefault(p => p.Id == id);

            if (dados == null)
            {
                return "Não foi encontrado VideoGame para o ID informado!";
            }
            else
            {
                contexto.Remove(dados);
                contexto.SaveChanges();
            
                return "VideoGame excluído com sucesso!";
            
        }
    }
}